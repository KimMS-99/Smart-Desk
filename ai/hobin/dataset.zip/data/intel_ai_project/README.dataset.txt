# intel_ai_project > 2025-09-05 11:07am
https://universe.roboflow.com/sanggong/intel_ai_project-gywji

Provided by a Roboflow user
License: CC BY 4.0

